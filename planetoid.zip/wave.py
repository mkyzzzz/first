"""
Subcontroller module for Planetoids

This module contains the subcontroller to manage a single level (or wave) in the 
Planetoids game.  Instances of Wave represent a single level, and should correspond
to a JSON file in the Data directory. Whenever you move to a new level, you are 
expected to make a new instance of the class.

The subcontroller Wave manages the ship, the asteroids, and any bullets on screen. These 
are model objects. Their classes are defined in models.py.
Most of your work on this assignment will be in either this module or models.py.
Whether a helper method belongs in this module or models.py is often a complicated
issue.  If you do not know, ask on Ed Discussions and we will answer.

# YOUR NAME(S) AND NETID(S) HERE
# DATE COMPLETED HERE
"""
from game2d import *
from consts import *
from models import *
import random
import datetime

# PRIMARY RULE: Wave can only access attributes in models.py via getters/setters
# Level is NOT allowed to access anything in app.py (Subcontrollers are not permitted
# to access anything in their parent. To see why, take CS 3152)

class Wave(object):
    """
    This class controls a single level or wave of Planetoids.
    
    This subcontroller has a reference to the ship, asteroids, and any bullets on screen.
    It animates all of these by adding the velocity to the position at each step. It
    checks for collisions between bullets and asteroids or asteroids and the ship 
    (asteroids can safely pass through each other). A bullet collision either breaks
    up or removes a asteroid. A ship collision kills the player. 
    
    The player wins once all asteroids are destroyed.  The player loses if they run out
    of lives. When the wave is complete, you should create a NEW instance of Wave 
    (in Planetoids) if you want to make a new wave of asteroids.
    
    If you want to the game, tell this controller to draw, but do not update.  See
    subcontrollers.py from Lecture 25 for an example.  This class will be similar to
    than one in many ways.
    
    All attributes of this class are to be hidden. No attribute should be accessed 
    without going through a getter/setter first. However, just because you have an
    attribute does not mean that you have to have a getter for it. For example, the
    Planetoids app probably never needs to access the attribute for the bullets, so 
    there is no need for a getter there. But at a minimum, you need getters indicating
    whether you one or lost the game.
    """
    # LIST ANY ATTRIBUTES (AND THEIR INVARIANTS) HERE IF NECESSARY
    # THE ATTRIBUTES LISTED ARE SUGGESTIONS ONLY AND CAN BE CHANGED AS YOU SEE FIT
    # Attribute _data: The data from the wave JSON, for reloading 
    # Invariant: _data is a dict loaded from a JSON file
    #
    # Attribute _ship: The player ship to control 
    # Invariant: _ship is a Ship object
    #
    # Attribute _asteroids: the asteroids on screen 
    # Invariant: _asteroids is a list of Asteroid, possibly empty
    #
    # Attribute _bullets: the bullets currently on screen 
    # Invariant: _bullets is a list of Bullet, possibly empty
    #
    # Attribute _lives: the number of lives left 
    # Invariant: _lives is an int >= 0
    #
    # Attribute _firerate: the number of frames until the player can fire again 
    # Invariant: _firerate is an int >= 0
    
    # GETTERS AND SETTERS (ONLY ADD IF YOU NEED THEM)
    
    # INITIALIZER (standard form) TO CREATE SHIP AND ASTEROIDS
    def __init__(self, _data):
        """
        Initializes game objects such as ships and asteroid given their attributes
        accessed from the JSON file.

        This method initializes the attribute _data that is a dict loaded from 
        a JSON file, given in its parameter _data. 
        
        Furthermore, this method initializes additional attributes like _asteroids and 
        _bullets as an empty list initially. And initializes _firerate and _lives to 
        their consntants. 

        Parameter _data: _data is the data from wave JSON, for reloading.
        Precondition: _data is a dict loaded from a JSON fle.
        """
        self._data = _data
        self._ship = Ship(position = _data['ship']['position'],
         angle = _data['ship']['angle'])
        self._asteroids = []
        for x in _data['asteroids']:
            self._asteroids.append(Asteroid(size = x['size'], \
                                   position = x['position'], \
                                   direction = x['direction']))
        self._bullets = []
        self._firerate = 0
        self._lives = 3

    # UPDATE METHOD TO MOVE THE SHIP, ASTEROIDS, AND BULLETS
    def update(self, dt, input):
        """
        Animates a single frame. Called every 1/60 of a
        second.

        Parameter dt: The time since the last animation frame.
        Precondition: dt is a float.

        Parameter input: input from the user, such as what keys user 
        pressed down.
        Precondition input: input is a GInput, or none if user did not
        press any key or mouse.
        """
        if self._ship != None:
            if input.is_key_down('left'):
                self._ship.turn_left()
            if input.is_key_down('right'):
                self._ship.turn_right()
            if input.is_key_down('up'):
                self._ship.thrust()
            self._ship.move()            
            self._ship.wrapping()
            if input.is_key_down('spacebar'):
                self.make_bullet()

        for asteroids in self._asteroids:
            asteroids.move()            
            asteroids.wrapping()

        if self._bullets != None:
            for bullets in self._bullets:
                bullets.move()
            self.asteroid_bullet_coll()
            self.destroy_bullet()
      
        self.ship_asteroid_coll()
        self.reset(input)

    # DRAW METHOD TO DRAW THE SHIP, ASTEROIDS, AND BULLETS
    def draw(self, view):
        """
        Draws the game objects to the view.
        The game objects include ship, asteroid, and bullets. 

        Parameter view: an attribute of GView to display game object when called
        by the draw method.
        Precondition: view is an instance of GView.
        """
        if self._ship != None:
            self._ship.draw(view)
        if self._asteroids != None:
            for asteroids in self._asteroids:
                asteroids.draw(view)
        if self._bullets != None:
            for bullets in self._bullets:
                bullets.draw(view)

    # RESET METHOD FOR CREATING A NEW LIFE
    def reset(self, input):
        """
        Respawns ship after life lost and there are remaining lives. 
        Player presses 's' key to continue playing.
        """
        if self._lives > 0 and self._ship == None and input.is_key_down('s'):
            self._ship = Ship(position = self._data['ship']['position'],
            angle = self._data['ship']['angle'])
    
    # HELPER METHODS FOR PHYSICS AND COLLISION DETECTION
    def make_bullet(self):
        """
        Creates bullets relative to the fire rate of the ship.
        """
        if self._firerate ==0:
            self._firerate = BULLET_RATE
            self._bullets.append(Bullet(facing = self._ship.getFacing(),
                                x = self._ship.getX(),
                                y = self._ship.getY()))
        else:
            self._firerate -= 1

    def destroy_bullet(self):
        """
        If bullet is out of the dead zone, delete bullet from the list.
        """
        i = 0
        while i < len(self._bullets):
            if self._bullets[i].isOut():
                del self._bullets[i]
            else:
                i += 1
    
    def ship_asteroid_coll(self):
        """
        Checks if there is a collision between ship and asteroids.
        If there is a collision, set ship to None and subtract 1 from lives. 
        If ship collide with a large asteroid, the large asteroid is destroyed and
        split into three medium asteroids. If the asteroid is medium, it is destroyed and
        split into three small asteroids. Lastly if ship collide with a small asteroid, 
        the small asteroid is destroyed.
        """
        i = 0
        while i < len(self._asteroids) and self._ship != None:
            distance = math.sqrt((self._ship.getX()- 
                        self._asteroids[i].getX())**2 + (self._ship.getY()
                         - self._asteroids[i].getY())**2)
            if self._asteroids[i].getSize() == 'large':
                if distance < (SHIP_RADIUS + LARGE_RADIUS):
                    self.ship_break_large(i)
                    self._ship = None
                    self._lives -= 1
                else:
                    i += 1  
            elif self._asteroids[i].getSize() == 'medium':
                if distance < (SHIP_RADIUS + MEDIUM_RADIUS):
                    self.ship_break_medium(i)
                    self._ship = None
                    self._lives -= 1
                else:
                    i += 1  
            elif self._asteroids[i].getSize() == 'small':
                if distance < (SHIP_RADIUS + SMALL_RADIUS):
                    self.ship_break_small(i)
                    self._ship = None
                    self._lives -= 1
                else:
                    i += 1   

    def asteroid_bullet_coll(self):
        """
        Checks if there is a collision between bullet and asteroid.
        If there is a collision, destroy the bullet. If bullet collide with a 
        large asteroid, the large asteroid is destroyed and split into three 
        medium asteroids. If the asteroid is medium, it is destroyed and split 
        into three small asteroids. Lastly if the bullet collide with a small 
        asteroid, the small asteroid is destroyed.
        """
        i = 0
        while i < (len(self._asteroids)):
            n = 0
            while n < len(self._bullets) and i !=(len(self._asteroids)):
                distance= Vector2(self._asteroids[i].getX()-
                    self._bullets[n].getX(),self._asteroids[i].getY()-
                    self._bullets[n].getY()).length()
                if self._asteroids[i].getSize() == 'large':
                    if distance < (BULLET_RADIUS + LARGE_RADIUS):
                        self.break_large(i, n )
                        del self._bullets[n]
                    else:
                        n +=1
                elif self._asteroids[i].getSize() == 'medium':
                    if distance < (BULLET_RADIUS + MEDIUM_RADIUS):
                        self.break_medium(i, n)
                        del self._bullets[n]
                    else:
                        n +=1
                elif self._asteroids[i].getSize() == 'small':
                    if distance < (BULLET_RADIUS+ SMALL_RADIUS):
                        self.break_small(i)
                        del self._bullets[n]
                    else:
                        n +=1
            i +=1 

    def break_large(self, i, n):
        """
        Destroys the large asteroid that collided with bullet.
        Upon destruction, the large asteroid is split into three medium asteroids.

        Parameter i: the index of the asteroid in the list self._asteroid.
        precondition: i is an int and i is an index in self._asteroid.

        Parameter n: the index of the bullet in the list self._bullet.
        precondition: n is an int and n is an index in self._asteroid.
        """
        bullet = self._bullets[n]        
        bullet_velocity = bullet.getVelocity().normalize()
        angle = degToRad(120)

        resultant_vector1 = Vector2(bullet_velocity.x, bullet_velocity.y)
        resultant_vector2 =  Vector2(bullet_velocity.x * math.cos(angle) - 
                            bullet_velocity.y * math.sin(angle),
                           bullet_velocity.x * math.sin(angle) + 
                           bullet_velocity.y * math.cos(angle))
        resultant_vector3 = Vector2(bullet_velocity.x * math.cos(-angle) - 
                            bullet_velocity.y * math.sin(-angle),
                           bullet_velocity.x * math.sin(-angle) + 
                           bullet_velocity.y * math.cos(-angle))
        
        resultants = [resultant_vector1, resultant_vector2, resultant_vector3]

        for vectors in resultants:
            vectors.normalize()
            x = vectors.x.__mul__(MEDIUM_RADIUS) + self._asteroids[i].getX()
            y = vectors.y.__mul__(MEDIUM_RADIUS) + self._asteroids[i].getY()
            self._asteroids.append(Asteroid(size = 'medium', \
                                   position = [x,y], \
                                   direction = [vectors.x * MEDIUM_SPEED, 
                                                vectors.y* MEDIUM_SPEED]))
        del self._asteroids[i]

    def break_medium(self, i,n):
        """
        Destroy the medium asteroid that collided with bullet.
        Upon destruction, the medium asteroid is split into three small asteroids.

        Parameter i: the index of the asteroid in the list self._asteroid.
        precondition: i is an int and i is an index in self._asteroid.

        Parameter n: the index of the bullet in the list self._bullet.
        precondition: n is an int and n is an index in self._asteroid.
        """
        bullet = self._bullets[n]        
        bullet_velocity = bullet.getVelocity().normalize()

        angle = degToRad(120)

        resultant_vector1 = Vector2(bullet_velocity.x, bullet_velocity.y)
        resultant_vector2 =  Vector2(bullet_velocity.x * math.cos(angle) -
                                     bullet_velocity.y * math.sin(angle),
                                    bullet_velocity.x * math.sin(angle) + 
                                    bullet_velocity.y * math.cos(angle))
        resultant_vector3 = Vector2(bullet_velocity.x * math.cos(-angle) - 
                                    bullet_velocity.y * math.sin(-angle),
                                    bullet_velocity.x * math.sin(-angle) + 
                                    bullet_velocity.y * math.cos(-angle))
        
        resultants = [resultant_vector1, resultant_vector2, resultant_vector3]

        for vectors in resultants:
            vectors.normalize()
            x = vectors.x.__mul__(SMALL_RADIUS) + self._asteroids[i].getX()
            y = vectors.y.__mul__(SMALL_RADIUS) + self._asteroids[i].getY()
            self._asteroids.append(Asteroid(size = 'small', \
                                   position = [x,y], \
                                   direction = [vectors.x, vectors.y]))
        del self._asteroids[i]

    def break_small(self, i):
        """
        Destroys the small asteroid that collided with bullet.
        When bullet collides with small asteroid, small asteroid is deleted.

        Parameter i: the index of the asteroid in the list self._asteroid.
        precondition: i is an int and i is an index in self._asteroid.       
        """
        del self._asteroids[i]

    def ship_break_large(self, i):
        """
        Destroys the large asteroid that collided with ship.
        Upon destruction, the large asteroid is split into three medium asteroids.

        Parameter i: the index of the asteroid in the list self._asteroid.
        precondition: i is an int and i is an index in self._asteroid.        
        """
        if self._ship.getVelocity() == Vector2(0,0):
            ship_velocity = self._ship.getFacing().normalize()
        else:
            ship_velocity = self._ship.getVelocity().normalize()        
        angle = degToRad(120)
        
        resultant_vector1 = Vector2(ship_velocity.x, ship_velocity.y)
        resultant_vector2 =  Vector2(ship_velocity.x * math.cos(angle) - 
                                    ship_velocity.y * math.sin(angle),
                                    ship_velocity.x * math.sin(angle) + 
                                    ship_velocity.y * math.cos(angle))
        resultant_vector3 = Vector2(ship_velocity.x * math.cos(-angle) - 
                                    ship_velocity.y * math.sin(-angle),
                                    ship_velocity.x * math.sin(-angle) + 
                                    ship_velocity.y * math.cos(-angle))
        
        resultants = [resultant_vector1, resultant_vector2, resultant_vector3]

        for vectors in resultants:
            vectors.normalize()
            x = vectors.x.__mul__(MEDIUM_RADIUS) + self._asteroids[i].getX()
            y = vectors.y.__mul__(MEDIUM_RADIUS) + self._asteroids[i].getY()
            self._asteroids.append(Asteroid(size = 'medium', \
                                   position = [x,y], \
                                   direction = [vectors.x * MEDIUM_SPEED, 
                                                vectors.y* MEDIUM_SPEED]))
        del self._asteroids[i]

    def ship_break_medium(self, i):
        """
        Destroys the medium asteroid that collided with ship.
        Upon destruction, the medium asteroid is split into three small asteroids.

        Parameter i: the index of the asteroid in the list self._asteroid.
        precondition: i is an int and i is an index in self._asteroid.        
        """
        if self._ship.getVelocity() == Vector2(0,0):
            ship_velocity = self._ship.getFacing().normalize()
        else:
            ship_velocity = self._ship.getVelocity().normalize()                
        angle = degToRad(120)        
        resultant_vector1 = Vector2(ship_velocity.x, ship_velocity.y)
        resultant_vector2 =  Vector2(ship_velocity.x * math.cos(angle) - 
                                    ship_velocity.y * math.sin(angle),
                                    ship_velocity.x * math.sin(angle) + 
                                    ship_velocity.y * math.cos(angle))
        resultant_vector3 = Vector2(ship_velocity.x * math.cos(-angle) - 
                                    ship_velocity.y * math.sin(-angle),
                                    ship_velocity.x * math.sin(-angle) + 
                                    ship_velocity.y * math.cos(-angle))
        resultants = [resultant_vector1, resultant_vector2, resultant_vector3]
        for vectors in resultants:
            vectors.normalize()
            x = vectors.x.__mul__(SMALL_RADIUS) + self._asteroids[i].getX()
            y = vectors.y.__mul__(SMALL_RADIUS) + self._asteroids[i].getY()
            self._asteroids.append(Asteroid(size = 'small', \
                                   position = [x,y], \
                                   direction = [vectors.x * SMALL_SPEED, 
                                                vectors.y* SMALL_SPEED]))
        del self._asteroids[i]

    def ship_break_small(self, i):
        """
        Destory the small asteroid that collided with ship.
        Upon destruction, the small asteroid is deleted.

        Parameter i: the index of the asteroid in the list self._asteroid.
        precondition: i is an int and i is an index in self._asteroid.          
        """
        del self._asteroids[i]

    def ship_die(self):
        """
        Returns True if the ship is None.
        Returns False otherwise.
        """
        if self._ship == None:
            return True
        else:
            False

    def is_lives_gone(self):
        """
        Returns True if the total number of lives have been depleted.
        """
        return self._lives == 0 

    def is_asteroids_gone(self):
        """
        Returns True if all the asteroids on the screen have been destroyed. 
        return False if otherwise.
        """
        return len(self._asteroids) == 0 

    def remove_ship_bullet(self):
        """
        Remove ship and bullets from the screen.
        """
        self._ship = None
        self._bullets = None