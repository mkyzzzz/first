"""
Models module for Planetoids

This module contains the model classes for the Planetoids game. Anything that you
interact with on the screen is model: the ship, the bullets, and the planetoids.

We need models for these objects because they contain information beyond the simple
shapes like GImage and GEllipse. In particular, ALL of these classes need a velocity
representing their movement direction and speed (and hence they all need an additional
attribute representing this fact). But for the most part, that is all they need. You
will only need more complex models if you are adding advanced features like scoring.

You are free to add even more models to this module. You may wish to do this when you
add new features to your game, such as power-ups. If you are unsure about whether to
make a new class or not, please ask on Ed Discussions.

# YOUR NAME(S) AND NETID(S) HERE
# DATE COMPLETED HERE
"""
from consts import *
from game2d import *
from introcs import *
import math

# PRIMARY RULE: Models are not allowed to access anything in any module other than
# consts.py. If you need extra information from Gameplay, then it should be a 
# parameter in your method, and Wave should pass it as a argument when it calls 
# the method.

# START REMOVE
# HELPER FUNCTION FOR MATH CONVERSION
def degToRad(deg):
    """
    Returns the radian value for the given number of degrees
    
    Parameter deg: The degrees to convert
    Precondition: deg is a float
    """
    return math.pi*deg/180
# END REMOVE


class Bullet(GEllipse):
    """
    A class representing a bullet from the ship
    
    Bullets are typically just white circles (ellipses). The size of the bullet is 
    determined by constants in consts.py. However, we MUST subclass GEllipse, because 
    we need to add an extra attribute for the velocity of the bullet.
    
    The class Wave will need to look at this velocity, so you will need getters for
    the velocity components. However, it is possible to write this assignment with no 
    setters for the velocities. That is because the velocity is fixed and cannot change 
    once the bolt is fired.
    
    In addition to the getters, you need to write the __init__ method to set the starting
    velocity. This __init__ method will need to call the __init__ from GEllipse as a
    helper. This init will need a parameter to set the direction of the velocity.
    
    You also want to create a method to update the bolt. You update the bolt by adding
    the velocity to the position. While it is okay to add a method to detect collisions
    in this class, you may find it easier to process collisions in wave.py.
    """
    # LIST ANY ATTRIBUTES (AND THEIR INVARIANTS) HERE IF NECESSARY
    # Attribute _velocity: The current velocity of the bullet. _velocity is 
    #                       the direction and the speed of the bullet
    # Invariant: _velocity is a Vector2 Unit.

    # Attribute _facing: The current facing of the bullet. The bullet's facing
    #                    is depedent on the ship's facing.
    # Invariant: _facing is the a Vector2 Unit.

    # Attribute x: The current x-coordinate of the bullet at its position.
    # Invariant: x is number, either float or int.

    # Attribute y: The current y-coordinate of the bullet at its position.
    # Invariant: y is number, either float or int.

    # Attribute _firerate: The rate that are used to calculate when 
    #                      may a ship firea bullet.
    # Invariant: _firerate is an int and must be > 0.  

    # Attribute _out: A boolean that determines whether a bullet is outside deathzone.
    # Invariant: _out is a bool. 

    # GETTERS AND SETTERS (ONLY ADD IF YOU NEED THEM)
    def getVelocity(self):
        """
        Return the velocity of the bullet.
        """
        return self._velocity

    def getFacing(self):
        """
        Returns the facing of the bullet.
        """
        return self._facing

    def getX(self):
        """
        Return the x-cordinate of the bullet at its current position.
        """
        return self.x

    def getY(self):
        """
        Return the y-cordinate of the bullet at its current position.
        """
        return self.y

    # INITIALIZER TO SET THE POSITION AND VELOCITY
    def __init__(self, facing, x, y):
        """
        Initializes a bullet given its facing, and its x and y position accessed 
        from the ship.

        This init method is a subclass of GEllipse, where we call super init to set
        additional attributes such as x,y, fillcolor, width, and height to initialize the bullet. 

        This method also initialize additional attribute like _velocity, _firerate 
        and _out for the bullet.

        Parameter facing: Direction the bullet faces.
        Precondition: facing is a Vector2 unit.

        Parameter x: x coordinate of the bullet's position.
        Precondition: x is a int or float.

        parameter y: y coordinate of the bullet's position.
        Precondition: y is a int or float.
        """
        self._facing = facing.__mul__(SHIP_RADIUS) 
        bullet_x = self._facing.x.__add__(x)
        bullet_y = self._facing.y.__add__(y)
        super().__init__(x=bullet_x, y=bullet_y, 
                         width=BULLET_RADIUS, height=BULLET_RADIUS,
                         fillcolor=BULLET_COLOR)
        self._firerate = 0 
        self._velocity = facing.__mul__(BULLET_SPEED)
        self._out = False
                         
    # ADDITIONAL METHODS (MOVEMENT, COLLISIONS, ETC)    
    def move(self):
        """
        Move the bullet relative to its velocity and mark bullet if they 
        move outside the deadzone.
        """
        self.x += self._velocity.x
        self.y += self._velocity.y
        if self.x < -DEAD_ZONE or self.x > GAME_WIDTH+DEAD_ZONE:
            self._out = True
        if self.y > GAME_HEIGHT+DEAD_ZONE or self.y < - DEAD_ZONE:
            self._out = True

    def isOut(self):
        """
        Returns: True if bullet has gone out of the dead zone, False otherwise
        """
        return self._out


class Ship(GImage):
    """
    A class to represent the game ship.
    
    This ship is represented by an image. The size of the ship is determined by constants 
    in consts.py. However, we MUST subclass GEllipse, because we need to add an extra 
    attribute for the velocity of the ship, as well as the facing vecotr (not the same)
    thing.
    
    The class Wave will need to access these two values, so you will need getters for 
    them. But per the instructions,these values are changed indirectly by applying thrust 
    or turning the ship. That means you won't want setters for these attributes, but you 
    will want methods to apply thrust or turn the ship.
    
    This class needs an __init__ method to set the position and initial facing angle.
    This information is provided by the wave JSON file. Ships should start with a shield
    enabled.
    
    Finally, you want a method to update the ship. When you update the ship, you apply
    the velocity to the position. While it is okay to add a method to detect collisions 
    in this class, you may find it easier to process collisions in wave.py.
    """
    # LIST ANY ATTRIBUTES (AND THEIR INVARIANTS) HERE IF NECESSARY
    # Attributes _position: The current position of the ship.
    # Invariant: _position is a list that contains two float or int values.

    # Attributes _angle: The current rotated angle of the ship. 
    # Invariant: _angle is a int or float.

    # Attributes _velocity: The current velocity of the ship. _velocity represents the 
    #                       direction and speed of the ship.
    # Invariant: _velocity is a Vector2 unit.

    # Attributes _facing: The current direction of the ship's facing. _facing is 
    #                     dependent on the angle of the ship.
    # Invariant: _facing is a Vector2 unit.

    # Attributes x: The current x-coordinate of the ship at its position.
    # Invariant: x is a float or int.
    
    # Attributes y: The current y-coordinate of the ship at its position.
    # Invariant: y is a float or int.
    # GETTERS AND SETTERS (ONLY ADD IF YOU NEED THEM)
    def getPosition(self):
        """
        Returns position of ship.

        A list that contains two float or int values.
        """
        return self._position
    def getAngle(self):
        """
        Returns the rotated angle of the ship.

        This angle value is returned by the rotation by the user to turn the ship.
        """
        return self._angle
    def getVelocity(self):
        """
        Return ship Velocity.
        """
        return self._velocity
    def getFacing(self):
        """
        Returns the direction of where the ship is facing based on the angle of 
        rotation inputted and modified by the user.
        """
        return self._facing 

    def getX(self):
        """
        Return the x-cordinate of the ship at its current position.
        """
        return self.x

    def getY(self):
        """
        Return the y-cordinate of the ship at its current position.
        """
        return self.y

    # INITIALIZER TO CREATE A NEW SHIP
    def __init__(self, position, angle):
        """
        Initializes a ship given its position and angle accessed from the JSON file.

        This init method is a subclass of GImage, where we call super init to set
        additional attributes such as x,y, source, width, and height to initialize the ship. 

        This method also initialize additional attribute like _velocity for the ship.

        Parameter position: position of the ship.
        Precondition: position is a list that contains two float or int values.

        Paramter angle: rotated angle of the ship.
        Precondition: angle is a int or float.
        """
        self._position = position 
        super().__init__(x=self._position[0], y =self._position[1], source = SHIP_IMAGE,
        width =2*SHIP_RADIUS, height = 2*SHIP_RADIUS)
        self._velocity = Vector2(0,0)
        self._angle = angle
        self._facing = Vector2(math.cos(degToRad(self.angle)), math.sin(degToRad(self.angle)))

    # ADDITIONAL METHODS (MOVEMENT, COLLISIONS, ETC)
    def turn_left(self):
        """
        Turn the ship left.
        """
        self.angle += SHIP_TURN_RATE
        self._facing.x = math.cos(degToRad(self.angle))
        self._facing.y = math.sin(degToRad(self.angle))

    def turn_right(self):
        """
        Turn the ship right.
        """
        self.angle -= SHIP_TURN_RATE
        self._facing.x = math.cos(degToRad(self.angle))
        self._facing.y = math.sin(degToRad(self.angle))

    def thrust(self):
        """
        Create thrust and add velocity to the ship.
        """
        impulse = self._facing.__mul__(SHIP_IMPULSE)
        new_velocity = self._velocity + impulse
        self._velocity = self._velocity + new_velocity
        if  self._velocity.length() > SHIP_MAX_SPEED:
            self._velocity.normalize()
            self._velocity = self._velocity.__mul__(SHIP_MAX_SPEED)

    def move(self):
        """
        Move the Ship relative to its velocity.
        """
        self.x += self._velocity.x
        self.y += self._velocity.y

    def wrapping(self):
        """
        Wraps the Ship when it goes off screen. When ship goes off screen, 
        we wrap it around to the other side. 

        Ex. if Ship goes offscreen to the left, it should come back around on the right.
        And if Ship going offscreen to the top, it should come back around to the bottom
        """
        if self.x > GAME_WIDTH+DEAD_ZONE:
            self.x = -DEAD_ZONE
        if self.x < -DEAD_ZONE:
            self.x = GAME_WIDTH+DEAD_ZONE
        if self.y < -DEAD_ZONE:
            self.y = GAME_HEIGHT+DEAD_ZONE
        if self.y > GAME_HEIGHT+DEAD_ZONE:
            self.y = -DEAD_ZONE


class Asteroid(GImage):
    """
    A class to represent a single asteroid.
    
    Asteroids are typically are represented by images. Asteroids come in three 
    different sizes (SMALL_ASTEROID, MEDIUM_ASTEROID, and LARGE_ASTEROID) that 
    determine the choice of image and asteroid radius. We MUST subclass GImage, because 
    we need extra attributes for both the size and the velocity of the asteroid.
    
    The class Wave will need to look at the size and velocity, so you will need getters 
    for them.  However, it is possible to write this assignment with no setters for 
    either of these. That is because they are fixed and cannot change when the planetoid 
    is created. 
    
    In addition to the getters, you need to write the __init__ method to set the size
    and starting velocity. Note that the SPEED of an asteroid is defined in const.py,
    so the only thing that differs is the velocity direction.
    
    You also want to create a method to update the asteroid. You update the asteroid 
    by adding the velocity to the position. While it is okay to add a method to detect 
    collisions in this class, you may find it easier to process collisions in wave.py.
    """
    # LIST ANY ATTRIBUTES (AND THEIR INVARIANTS) HERE IF NECESSARY
    # Attribute _size: The size of the asteriod.
    # Invariant: _size is a string that is either 'small', 'medium', or 'large'.

    # Attribute _velocity: The current velocity of the asteroid. _veloicty is the 
    #                       direction and the speed of the asteroid.
    # Invariant: _velocity is a Vector2 unit.
    
    # Attribute _position: The current position of the asteroid.
    # Invariant: _position is a list that contains two float or int values.

    # Attribute _direction: The current direction and speed of the asteroid.
    # Invariant: _direction a Vector2 unit.

    # Attribute x: The current x coordinate of the asteroids at its position.
    # Invariant: x is a float or int.

    # Attribute y: The current y coordinate of the asteroids at its position.
    # Invariant: y is a float or int.

    # GETTERS AND SETTERS (ONLY ADD IF YOU NEED THEM)
    def getSize(self):
        """
        Return Asteroid Size.

        A string that is either 'small', 'medium', or 'large'.
        """
        return self._size

    def getVelocity(self):
        """
        Return Asteroid Velocity.

        A Vector2 Unit that represents magnitude and direction.
        """
        return self._velocity 

    def getPosition(self):
        """
        Return the postition of the asteroid. 

        Position is a list that contains two values: x and y position of the asteroid. 
        """
        return self._position

    def getX(self):
        """
        Return the x-cordinate of the asteroid at its current position.
        """
        return self.x

    def getY(self):
        """
        Return the y-cordinate of the asteroid at its current position.
        """
        return self.y
    
    # INITIALIZER TO CREATE A NEW ASTEROID
    def __init__(self, size, position, direction):
        """
        Initializes a asteriod given its size, position, and angle accessed from the JSON file.

        This init method is a subclass of GImage, where we call super init to set
        additional attributes such as x,y, source, width, and height to initialize the asteriod. 

        This method also initialize additional attribute like _velocity for the asteriod.

        However, this init method sets attributes differently dependent on its given size. 
        Such attributes are source, width, height, and velocity. 

        Parameter size: size of the asteroid.
        Precondition: size is a string that is either 'small', 'medium', or 'large.

        Parameter position: position of the asteroid.
        Precondition: position is a list that contains two float or int values.

        Parameter direction: direction of the asteriod facing and moving. 
        Precondition: direction is a list that contains two float or int values.
        """
        self._position = position
        self._size = size
        self._direction = direction
        self._direction = Vector2(self._direction[0], self._direction[1])
        if self._direction != Vector2(0,0):
            self._direction.normalize()
        if size == 'large':
            super().__init__(x=self._position[0], y =self._position[1], source = LARGE_IMAGE, 
            width =2*LARGE_RADIUS, height = 2*LARGE_RADIUS)
            self._velocity = self._direction * LARGE_SPEED
        if size == 'medium':
            super().__init__(x=self._position[0], y =self._position[1], source = MEDIUM_IMAGE, 
            width =2*MEDIUM_RADIUS, height = 2*MEDIUM_RADIUS)
            self._velocity = self._direction * MEDIUM_SPEED
        if size == 'small':
            super().__init__(x=self._position[0], y =self._position[1], source = SMALL_IMAGE, 
            width =2*SMALL_RADIUS, height = 2*SMALL_RADIUS) 
            self._velocity = self._direction * SMALL_SPEED

    # ADDITIONAL METHODS (MOVEMENT, COLLISIONS, ETC)
    def move(self):
        """
        Moves the Asteroid relative to its velocity.
        """
        self.x += self._velocity.x
        self.y += self._velocity.y

    def wrapping(self):
        """
        Wraps the Asteroid when it goes off screen. When Asteroids goes off screen, 
        we wrap it around to the other side. 

        Ex. if Asteroids goes offscreen to the left, it should come back around on the right.
        And if objects going offscreen to the top, it should come back around to the bottom
        """
        if self.x > GAME_WIDTH+DEAD_ZONE:
            self.x = -DEAD_ZONE
        if self.x < -DEAD_ZONE:
            self.x = GAME_WIDTH+DEAD_ZONE
        if self.y < -DEAD_ZONE:
            self.y = GAME_HEIGHT+DEAD_ZONE
        if self.y > GAME_HEIGHT+DEAD_ZONE:
            self.y = -DEAD_ZONE

